function fig = fig06_open_set_rejection(cfg)
%FIG06_OPEN_SET_REJECTION Proposal Figure 6, Eqs. (11)-(12).
if nargin < 1
    cfg = setup_nsfc_paths();
end
cal = read_demo_table(cfg, 'calibration_scores.csv');
features = read_demo_table(cfg, 'openset_features.csv');

fig = new_figure(cfg, [40 40 1800 1180]);
% Use three equal analytical columns; the schematic itself is compacted
% below so the first row remains balanced and labels stay separated.
tl = tiledlayout(fig, 2, 3, 'Padding', 'compact', 'TileSpacing', 'compact');
title(tl, 'Figure 6. Angular-margin learning and regularized Mahalanobis rejection', ...
    'FontName', cfg.font_name, 'FontSize', 17, 'FontWeight', 'bold');

ax1 = nexttile(tl, 1); hold(ax1, 'on');
axis(ax1, [0 1 0 1]); axis(ax1, 'off');
draw_flow_box(ax1, [0.03 0.71 0.35 0.17], ...
    ['Spatial branch' newline 'texture + directional structure'], ...
    [0.90 0.95 1.00], cfg.colors.blue);
draw_flow_box(ax1, [0.03 0.40 0.35 0.17], ...
    ['Frequency branch [36]' newline 'radial energy + directional bands + phase'], ...
    [0.96 0.92 0.98], cfg.colors.purple);
draw_flow_box(ax1, [0.57 0.54 0.40 0.20], ...
    ['Normalized fusion h' newline ...
    'rotation-tolerant +' newline 'direction-sensitive evidence'], ...
    [0.90 0.97 0.91], cfg.colors.green, 'FontWeight', 'bold');
draw_arrow(ax1, [0.39 0.79], [0.56 0.66], cfg.colors.blue, 1.4);
draw_arrow(ax1, [0.39 0.48], [0.56 0.62], cfg.colors.purple, 1.4);
text(ax1, 0.50, 0.14, ...
    'UniSpector [36] motivates spatial-frequency complementarity; no source figure is copied.', ...
    'HorizontalAlignment', 'center', 'Interpreter', 'none', ...
    'FontSize', 8.5, 'Color', cfg.colors.gray);
title(ax1, '(a) Spatial-frequency evidence fusion');

ax2 = nexttile(tl, 2); hold(ax2, 'on');
% Preserve a quiet header band for the panel title; the geometry is square.
theta = linspace(0, 2*pi, 360);
plot(ax2, cos(theta), sin(theta), '-', 'Color', [0.80 0.83 0.87]);
classAngles = deg2rad([20 145 260]);
margin = deg2rad(18);
classColors = [cfg.colors.blue; cfg.colors.orange; cfg.colors.green];
for c = 1:3
    w = [cos(classAngles(c)); sin(classAngles(c))];
    plot(ax2, [0 w(1)], [0 w(2)], '-', 'Color', classColors(c,:), ...
        'LineWidth', 2.3);
    arc = linspace(classAngles(c)-margin, classAngles(c)+margin, 50);
    plot(ax2, 0.87*cos(arc), 0.87*sin(arc), '-', ...
        'Color', classColors(c,:), 'LineWidth', 4);
end
knownAngles = [8 27 132 151 247 268 278];
scatter(ax2, cosd(knownAngles), sind(knownAngles), 34, ...
    cfg.colors.blue, 'filled', 'MarkerEdgeColor', 'white');
unknownAngles = [82 205 326];
scatter(ax2, cosd(unknownAngles), sind(unknownAngles), 45, ...
    cfg.colors.red, 'x', 'LineWidth', 2);
axis(ax2, 'equal'); xlim(ax2, [-1.15 1.15]); ylim(ax2, [-1.15 1.15]);
xlabel(ax2, 'normalized feature h_1'); ylabel(ax2, 'normalized feature h_2');
text(ax2, 0.5, 1.06, '(b) Known-class angular compactness, Eq. (11)', ...
    'Units', 'normalized', 'HorizontalAlignment', 'center', ...
    'FontName', cfg.font_name, 'FontSize', 8.5, ...
    'FontWeight', 'normal', 'Color', cfg.colors.dark, ...
    'Clipping', 'off');
grid(ax2, 'on'); apply_axes_style(ax2, cfg);

ax3 = nexttile(tl, 3); hold(ax3, 'on');
knownScores = cal.min_mahalanobis(cal.is_known == 1);
knownAlpha = unique(cal.target_alpha(cal.is_known == 1));
knownAlpha = knownAlpha(isfinite(knownAlpha));
if numel(knownAlpha) ~= 1
    error('PortableFigures:InvalidTargetAlpha', ...
        'Known calibration rows must contain one unique target_alpha.');
end
targetAlpha = knownAlpha(1);
eta = empirical_quantile(knownScores, 1-targetAlpha);
[knownSorted, ~] = sort(knownScores);
knownCdf = (1:numel(knownSorted)) / numel(knownSorted);
stairs(ax3, knownSorted, knownCdf, 'Color', cfg.colors.blue, ...
    'LineWidth', 2, 'DisplayName', 'known calibration ECDF');
thresholdLine = xline(ax3, eta, '--', sprintf('\\eta = %.2f', eta), ...
    'Color', cfg.colors.red, 'LineWidth', 1.8, ...
    'LabelVerticalAlignment', 'bottom');
thresholdLine.HandleVisibility = 'off';
targetLine = yline(ax3, 1-targetAlpha, ':', ...
    sprintf('1-\\alpha = %.2f', 1-targetAlpha));
targetLine.HandleVisibility = 'off';
xlabel(ax3, 'minimum Mahalanobis score');
ylabel(ax3, 'empirical cumulative probability');
title(ax3, '(c) Independent calibration threshold');
xlim(ax3, [0 max(cal.min_mahalanobis)*1.05]); ylim(ax3, [0 1.02]);
grid(ax3, 'on'); legend(ax3, 'Location', 'southeast'); apply_axes_style(ax3, cfg);

ax4 = nexttile(tl, 4, [1 3]); hold(ax4, 'on');
classIds = unique(features.class_id(features.is_known == 1), 'stable');
baseColors = [cfg.colors.blue; cfg.colors.orange; cfg.colors.green; ...
    cfg.colors.purple; cfg.colors.cyan];
if numel(classIds) <= size(baseColors,1)
    ellipsoidColors = baseColors(1:numel(classIds),:);
else
    ellipsoidColors = lines(numel(classIds));
end
[sphereX, sphereY, sphereZ] = sphere(24);
spherePoints = [sphereX(:).'; sphereY(:).'; sphereZ(:).'];
for i = 1:numel(classIds)
    rows = features.class_id == classIds(i) & features.is_known == 1;
    H = [features.f001(rows).'; features.f002(rows).'; features.f003(rows).'];
    mu = mean(H, 2);
    centered = H - mu;
    SigmaHat = (centered * centered.') / max(1, size(H,2)-1);
    Sigma = shrink_covariance(SigmaHat, 0.28, 0.03);
    [V,D] = eig(Sigma);
    boundary = repmat(mu, 1, size(spherePoints,2)) + ...
        V * diag(sqrt(eta * max(diag(D),0))) * spherePoints;
    surf(ax4, reshape(boundary(1,:), size(sphereX)), ...
        reshape(boundary(2,:), size(sphereY)), ...
        reshape(boundary(3,:), size(sphereZ)), ...
        'FaceColor', 'none', ...
        'EdgeColor', ellipsoidColors(i,:), ...
        'HandleVisibility', 'off');
    scatter3(ax4, H(1,:), H(2,:), H(3,:), 28, ellipsoidColors(i,:), ...
        'filled', 'MarkerEdgeColor', 'white', ...
        'DisplayName', sprintf('known class %g', classIds(i)));
end
unknownRows = features.is_known == 0;
scatter3(ax4, features.f001(unknownRows), features.f002(unknownRows), ...
    features.f003(unknownRows), 75, cfg.colors.red, 'x', ...
    'LineWidth', 2.2, 'DisplayName', 'unknown / rejected');
xlabel(ax4, 'h_1'); ylabel(ax4, 'h_2'); zlabel(ax4, 'h_3');
title(ax4, '(d) 3-D class-conditional Mahalanobis ellipsoids, Eq. (12)');
view(ax4, [-42 24]); grid(ax4, 'on'); axis(ax4, 'vis3d');
legend(ax4, 'Location', 'northeast'); apply_axes_style(ax4, cfg);

add_figure_note(fig, 'simulation');
end
