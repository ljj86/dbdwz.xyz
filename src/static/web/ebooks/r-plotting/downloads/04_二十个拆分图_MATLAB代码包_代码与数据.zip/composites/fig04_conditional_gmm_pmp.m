function fig = fig04_conditional_gmm_pmp(cfg)
%FIG04_CONDITIONAL_GMM_PMP Proposal Figure 4, Eqs. (4)-(7).
if nargin < 1
    cfg = setup_nsfc_paths();
end
T = read_demo_table(cfg, 'gmm_components.csv');
fig = new_figure(cfg, [60 60 1550 980]);
tl = tiledlayout(fig, 2, 2, 'Padding', 'compact', 'TileSpacing', 'compact');
title(tl, 'Figure 4. Conditional Gaussian prototypes and posterior mean path', ...
    'FontName', cfg.font_name, 'FontSize', 17, 'FontWeight', 'bold');

ax1 = nexttile(tl, 1); hold(ax1, 'on');
x = linspace(-4, 4, 76); y = linspace(-3.5, 3.5, 68);
[X, Y] = meshgrid(x, y);
ZA = mixture_density(T, "A", X, Y);
ZB = mixture_density(T, "B", X, Y);
surf(ax1, X, Y, ZA, 'EdgeColor', 'none');
surf(ax1, X, Y, ZB, 'EdgeColor', cfg.colors.orange, ...
    'FaceColor', 'none', 'LineStyle', ':', 'LineWidth', 0.45);
colormap(ax1, nsfc_colormap(cfg, 'viridis', 256));
view(ax1, [-43 29]); xlim(ax1, [-4 4]); ylim(ax1, [-3.5 3.5]);
xlabel(ax1, 'feature z_1'); ylabel(ax1, 'feature z_2'); zlabel(ax1, 'p_l(z|c)');
title(ax1, '(a) 3-D context-conditioned GMM probability, Eq. (4)');
grid(ax1, 'on'); apply_axes_style(ax1, cfg);

ax2 = nexttile(tl, 2); hold(ax2, 'on');
SigmaHat = [3.0 1.75; 1.75 1.15];
alphas = [0 0.35 0.80];
styles = {'-', '--', ':'};
colors = [cfg.colors.red; cfg.colors.orange; cfg.colors.green];
for i = 1:numel(alphas)
    S = shrink_covariance(SigmaHat, alphas(i), 0.02);
    ellipseHandle = draw_cov_ellipse(ax2, [0;0], S, 4.0, ...
        colors(i,:), styles{i}, 2.0);
    ellipseHandle.HandleVisibility = 'off';
    plot(ax2, nan, nan, styles{i}, 'Color', colors(i,:), ...
        'LineWidth', 2, 'DisplayName', sprintf('\\alpha = %.2f', alphas(i)));
end
axis(ax2, 'equal'); xlim(ax2, [-4 4]); ylim(ax2, [-3 3]);
xlabel(ax2, 'feature direction 1'); ylabel(ax2, 'feature direction 2');
title(ax2, '(b) Covariance shrinkage stabilizes anisotropy, Eq. (5)');
legend(ax2, 'Location', 'northeast'); grid(ax2, 'on'); apply_axes_style(ax2, cfg);

ax3 = nexttile(tl, 3); hold(ax3, 'on');
lambda = logspace(-2, 1.5, 240);
taus = [0.25 0.70 1.40];
for i = 1:numel(taus)
    retention = lambda ./ (lambda + taus(i)^2);
    semilogx(ax3, lambda, retention, 'LineWidth', 2, ...
        'DisplayName', sprintf('\\tau = %.2f', taus(i)));
end
referenceLine = yline(ax3, 0.5, ':', '50% retention', ...
    'LabelHorizontalAlignment', 'left');
referenceLine.HandleVisibility = 'off';
xlabel(ax3, 'covariance eigenvalue \lambda');
ylabel(ax3, 'retained deviation \lambda/(\lambda+\tau^2)');
title(ax3, '(c) Stronger contraction in low-variance directions, Eq. (6)');
ylim(ax3, [0 1.02]); grid(ax3, 'on'); legend(ax3, 'Location', 'southeast');
apply_axes_style(ax3, cfg);

ax4 = nexttile(tl, 4); hold(ax4, 'on');
[weights, means, covariances] = context_parameters(T, "A");
energy = -log(max(ZA, realmin));
energy = min(energy, empirical_quantile(energy(:), 0.97));
surf(ax4, X, Y, energy, 'EdgeColor', 'none', ...
    'HandleVisibility', 'off');
colormap(ax4, nsfc_colormap(cfg, 'viridis', 256));
x0 = [3.1; -2.6];
tau = 0.8;
[singleStep, ~] = gmm_posterior_mean(x0, weights, means, covariances, tau);
path = zeros(2, 9); path(:,1) = x0;
beta = 0.65;
for t = 1:8
    posterior = gmm_posterior_mean(path(:,t), weights, means, covariances, tau);
    path(:,t+1) = (1-beta) * path(:,t) + beta * posterior;
end
z0 = interp2(X, Y, energy, x0(1), x0(2), 'linear');
zSingle = interp2(X, Y, energy, singleStep(1), singleStep(2), 'linear');
zPath = interp2(X, Y, energy, path(1,:), path(2,:), 'linear');
zMeans = interp2(X, Y, energy, means(1,:), means(2,:), 'linear');
plot3(ax4, x0(1), x0(2), z0, 'kx', 'MarkerSize', 10, 'LineWidth', 2, ...
    'DisplayName', 'observation');
plot3(ax4, singleStep(1), singleStep(2), zSingle, 'o', ...
    'Color', cfg.colors.orange, 'MarkerFaceColor', cfg.colors.orange, ...
    'DisplayName', 'single posterior mean');
plot3(ax4, path(1,:), path(2,:), zPath, '-o', 'Color', cfg.colors.purple, ...
    'MarkerFaceColor', 'white', 'LineWidth', 1.8, ...
    'DisplayName', 'multi-step PMP, Eq. (7)');
plot3(ax4, means(1,:), means(2,:), zMeans, 'p', 'MarkerSize', 12, ...
    'Color', cfg.colors.green, 'MarkerFaceColor', cfg.colors.green, ...
    'DisplayName', 'component means');
xlim(ax4, [-4 4]); ylim(ax4, [-3.5 3.5]);
xlabel(ax4, 'feature z_1'); ylabel(ax4, 'feature z_2'); zlabel(ax4, '-log p_l(z|c)');
title(ax4, '(d) 3-D posterior mean/PMP descent, Eqs. (6)-(7)');
view(ax4, [-38 28]);
legend(ax4, 'Location', 'southwest'); grid(ax4, 'on'); apply_axes_style(ax4, cfg);

add_figure_note(fig, 'simulation');
end

function Z = mixture_density(T, contextName, X, Y)
[weights, means, covariances] = context_parameters(T, contextName);
points = [X(:).'; Y(:).'];
z = zeros(1, size(points,2));
for k = 1:numel(weights)
    z = z + weights(k) * exp(gaussian_logpdf_chol( ...
        points, means(:,k), covariances(:,:,k)));
end
Z = reshape(z, size(X));
end

function [weights, means, covariances] = context_parameters(T, contextName)
rows = T.context_id == contextName;
S = T(rows,:);
if ismember('scale_id', S.Properties.VariableNames)
    scaleIds = unique(S.scale_id, 'stable');
    if isempty(scaleIds)
        error('PortableFigures:MissingGMMContext', ...
            'No GMM rows found for context %s.', contextName);
    end
    % This visualization is one feature scale at a time. Select the first
    % stable scale instead of accidentally mixing components across scales.
    S = S(S.scale_id == scaleIds(1), :);
end
weights = S.weight.';
if isempty(weights) || any(weights <= 0)
    error('PortableFigures:InvalidGMMWeights', ...
        'Context %s must contain positive mixture weights.', contextName);
end
weights = weights / sum(weights);
means = [S.mu1.'; S.mu2.'];
K = height(S);
covariances = zeros(2,2,K);
for k = 1:K
    covariances(:,:,k) = [S.sigma11(k) S.sigma12(k); ...
        S.sigma12(k) S.sigma22(k)];
    if any(eig(covariances(:,:,k)) <= 0)
        error('PortableFigures:InvalidGMMCovariance', ...
            'Context %s component %d is not positive definite.', ...
            contextName, k);
    end
end
end
