function fig = figS01_parameter_sensitivity(cfg)
%FIGS01_PARAMETER_SENSITIVITY Formula-linked sensitivity analysis.
if nargin < 1
    cfg = setup_nsfc_paths();
end
fig = new_figure(cfg, [40 40 1600 980]);
tl = tiledlayout(fig, 2, 2, 'Padding', 'compact', 'TileSpacing', 'compact');
title(tl, 'Supplementary Figure S1. Formula-linked parameter sensitivity', ...
    'FontName', cfg.font_name, 'FontSize', 17, 'FontWeight', 'bold');

ax1 = nexttile(tl, 1);
alpha = linspace(0, 1, 48);
epsilon = logspace(-6, -0.3, 44);
[A, E] = meshgrid(alpha, epsilon);
rawEigenvalues = [0.015 0.20 4.0];
d = numel(rawEigenvalues);
meanEigenvalue = mean(rawEigenvalues);
conditionNumber = zeros(size(A));
for i = 1:numel(A)
    shrunk = (1-A(i))*rawEigenvalues + A(i)*meanEigenvalue + E(i);
    conditionNumber(i) = max(shrunk) / min(shrunk);
end
surf(ax1, A, log10(E), log10(conditionNumber), 'EdgeColor', 'none');
colormap(ax1, nsfc_colormap(cfg, 'viridis', 256));
colorbar(ax1); view(ax1, [-42 27]);
xlabel(ax1, 'shrinkage \alpha'); ylabel(ax1, 'log_{10} \epsilon');
zlabel(ax1, 'log_{10} condition number');
title(ax1, '(a) Eq. (5): conditioning improves with shrinkage/ridge');
grid(ax1, 'on'); apply_axes_style(ax1, cfg);

ax2 = nexttile(tl, 2);
lambda = logspace(-2, 1.2, 54);
tau = linspace(0.05, 1.8, 48);
[L, Tau] = meshgrid(lambda, tau);
retention = L ./ (L + Tau.^2);
surf(ax2, log10(L), Tau, retention, 'EdgeColor', 'none');
colormap(ax2, nsfc_colormap(cfg, 'viridis', 256));
colorbar(ax2); view(ax2, [-43 27]);
xlabel(ax2, 'log_{10} covariance eigenvalue \lambda');
ylabel(ax2, 'noise scale \tau'); zlabel(ax2, '\lambda/(\lambda+\tau^2)');
title(ax2, '(b) Eq. (6): direction-dependent retained deviation');
grid(ax2, 'on'); apply_axes_style(ax2, cfg);

ax3 = nexttile(tl, 3);
beta = linspace(0.05, 1, 50);
tau2 = linspace(0.05, 1.8, 48);
[B, Tau2] = meshgrid(beta, tau2);
lambdaFixed = 0.35;
rho = 1 - B .* Tau2.^2 ./ (lambdaFixed + Tau2.^2);
surf(ax3, B, Tau2, rho, 'EdgeColor', 'none');
colormap(ax3, nsfc_colormap(cfg, 'viridis', 256));
colorbar(ax3); view(ax3, [-43 27]);
xlabel(ax3, 'step size \beta'); ylabel(ax3, 'noise scale \tau');
zlabel(ax3, 'local contraction \rho');
title(ax3, '(c) Extension E1 from Eq. (7): PMP contraction');
grid(ax3, 'on'); apply_axes_style(ax3, cfg);

ax4 = nexttile(tl, 4); hold(ax4, 'on');
difficulty = linspace(0,1,220);
gammas = [0.3 0.7 1.2 2.0];
for i = 1:numel(gammas)
    plot(ax4, difficulty, (0.05+difficulty).^gammas(i), ...
        'LineWidth', 2, 'DisplayName', sprintf('\\gamma=%.1f', gammas(i)));
end
xlabel(ax4, 'historical difficulty a_i');
ylabel(ax4, 'weight w_i=(\delta+a_i)^\gamma');
title(ax4, '(d) Eq. (10): Soft Mining response');
legend(ax4, 'Location', 'northwest'); grid(ax4, 'on');
apply_axes_style(ax4, cfg);

add_figure_note(fig, 'simulation');
end
