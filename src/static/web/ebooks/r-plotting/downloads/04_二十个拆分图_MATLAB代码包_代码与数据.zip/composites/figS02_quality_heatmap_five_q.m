function fig = figS02_quality_heatmap_five_q(cfg)
%FIGS02_QUALITY_HEATMAP_FIVE_Q Equation (8) heatmap and Eq. (2) evidence.
if nargin < 1
    cfg = setup_nsfc_paths();
end
patches = read_demo_table(cfg, 'patch_scores.csv');
quality = read_demo_table(cfg, 'quality_five_dim.csv');
if ismember('sample_id', patches.Properties.VariableNames)
    patchSamples = unique(patches.sample_id, 'stable');
    if numel(patchSamples) > 1
        warning('PortableFigures:MultiplePatchSamples', ...
            'patch_scores.csv has multiple samples; plotting %s only.', ...
            patchSamples(1));
        patches = patches(patches.sample_id == patchSamples(1), :);
    end
end
fig = new_figure(cfg, [40 40 1600 980]);
tl = tiledlayout(fig, 2, 2, 'Padding', 'compact', 'TileSpacing', 'compact');
title(tl, 'Supplementary Figure S2. Multi-scale deviation, heatmap, and five-dimensional evidence', ...
    'FontName', cfg.font_name, 'FontSize', 16, 'FontWeight', 'bold');

scaleIds = unique(patches.scale_id, 'stable');
maps = cell(numel(scaleIds),1);
for s = 1:numel(scaleIds)
    rows = patches.scale_id == scaleIds(s);
    xs = unique(patches.x(rows)); ys = unique(patches.y(rows));
    if numel(xs) < 2 || numel(ys) < 2
        error('PortableFigures:InvalidPatchGrid', ...
            'Each scale must form a grid with at least two x and two y values.');
    end
    map = nan(numel(ys), numel(xs));
    for i = find(rows).'
        xi = find(xs == patches.x(i), 1);
        yi = find(ys == patches.y(i), 1);
        map(yi,xi) = patches.mask_ratio(i) * ...
            (patches.nll(i) + patches.gamma(i)*patches.posterior_residual2(i));
    end
    maps{s} = map;
end

ax1 = nexttile(tl, 1); hold(ax1, 'on');
imagesc(ax1, maps{1}); axis(ax1, 'image'); set(ax1, 'YDir', 'normal');
colormap(ax1, nsfc_colormap(cfg, 'viridis', 256)); colorbar(ax1);
xlabel(ax1, 'patch column'); ylabel(ax1, 'patch row');
title(ax1, sprintf('(a) Scale %d masked patch deviation m_i a_i, Eq. (8)', scaleIds(1)));
apply_axes_style(ax1, cfg);

ax2 = nexttile(tl, 2); hold(ax2, 'on');
fine = maps{1};
coarse = maps{min(2,numel(maps))};
[xc,yc] = meshgrid(linspace(1,size(fine,2),size(coarse,2)), ...
    linspace(1,size(fine,1),size(coarse,1)));
[xf,yf] = meshgrid(1:size(fine,2),1:size(fine,1));
coarseUp = interp2(xc,yc,coarse,xf,yf,'linear');
fused = 0.65*fine + 0.35*coarseUp;
imagesc(ax2, fused); axis(ax2, 'image'); set(ax2, 'YDir', 'normal');
colormap(ax2, nsfc_colormap(cfg, 'viridis', 256)); colorbar(ax2);
xlabel(ax2, 'pixel-space proxy column'); ylabel(ax2, 'pixel-space proxy row');
title(ax2, '(b) Multi-scale upsampled defect heatmap A, Eq. (8)');
apply_axes_style(ax2, cfg);

ax3 = nexttile(tl, 3); hold(ax3, 'on');
qColumns = {'q_preserve','q_remove','q_boundary','q_context','q_hallucination'};
labels = {'preserve','remove','boundary','context','hallucination'};
angles = linspace(0, 2*pi, numel(labels)+1);
sampleRows = 1:min(3,height(quality));
for ring = [0.25 0.50 0.75 1.00]
    plot(ax3, ring*cos(angles), ring*sin(angles), ':', ...
        'Color', [0.78 0.80 0.83], 'HandleVisibility', 'off');
end
for spoke = angles(1:end-1)
    plot(ax3, [0 cos(spoke)], [0 sin(spoke)], ':', ...
        'Color', [0.78 0.80 0.83], 'HandleVisibility', 'off');
end
for r = sampleRows
    values = zeros(1,numel(qColumns));
    for k = 1:numel(qColumns)
        values(k) = quality.(qColumns{k})(r);
    end
    values = [values values(1)];
    plot(ax3, values.*cos(angles), values.*sin(angles), '-o', 'LineWidth', 1.8, ...
        'DisplayName', char(quality.sample_id(r)));
end
for k = 1:numel(labels)
    text(ax3, 1.13*cos(angles(k)), 1.13*sin(angles(k)), labels{k}, ...
        'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
        'FontSize', 8.5);
end
axis(ax3, 'equal'); xlim(ax3, [-1.25 1.25]); ylim(ax3, [-1.25 1.25]);
axis(ax3, 'off');
title(ax3, '(c) Five-dimensional quality evidence q, Eq. (2)');
legend(ax3, 'Location', 'southoutside', 'Orientation', 'horizontal');

ax4 = nexttile(tl, 4); hold(ax4, 'on');
Qcal = linspace(0.4, 7.5, 80) + 0.12*sin(1:80);
Qcal = sort(Qcal);
Qquery = linspace(min(Qcal), max(Qcal), 220);
score = zeros(size(Qquery));
n = numel(Qcal);
for i = 1:numel(Qquery)
    score(i) = 100 * (1 + sum(Qcal >= Qquery(i))) / (n+1);
end
plot(ax4, Qquery, score, 'Color', cfg.colors.purple, 'LineWidth', 2.2);
xlabel(ax4, 'image-level deviation Q (larger = worse)');
ylabel(ax4, 'calibrated quality percentile S_Q (larger = better)');
title(ax4, '(d) Extension E3: monotone calibration of Eq. (8)');
ylim(ax4, [0 102]); grid(ax4, 'on'); apply_axes_style(ax4, cfg);

add_figure_note(fig, 'simulation');
end
