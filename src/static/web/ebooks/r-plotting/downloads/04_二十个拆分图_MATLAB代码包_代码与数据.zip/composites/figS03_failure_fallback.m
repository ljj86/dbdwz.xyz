function fig = figS03_failure_fallback(cfg)
%FIGS03_FAILURE_FALLBACK Controlled contamination curves and fallback.
if nargin < 1
    cfg = setup_nsfc_paths();
end
T = read_demo_table(cfg, 'failure_curves.csv');
fig = new_figure(cfg, [40 40 1600 950]);
tl = tiledlayout(fig, 2, 2, 'Padding', 'compact', 'TileSpacing', 'compact');
title(tl, 'Supplementary Figure S3. Failure boundary and evidence-aware fallback', ...
    'FontName', cfg.font_name, 'FontSize', 17, 'FontWeight', 'bold');

methods = unique(T.method, 'stable');
baseColors = [cfg.colors.gray; cfg.colors.orange; cfg.colors.green; ...
    cfg.colors.blue; cfg.colors.purple; cfg.colors.cyan];
if numel(methods) <= size(baseColors,1)
    colors = baseColors(1:numel(methods),:);
else
    colors = lines(numel(methods));
end
metrics = {'purity','coverage','pixel_auroc'};
metricTitles = {
    '(a) Prototype purity versus mask area';
    '(b) Effective coverage versus mask area';
    '(c) Localization AUROC versus mask area'
    };
for p = 1:3
    ax = nexttile(tl, p); hold(ax, 'on');
    for m = 1:numel(methods)
        rows = T.method == methods(m);
        [maskRatio, order] = sort(T.mask_ratio(rows));
        metricValues = T.(metrics{p})(rows);
        metricValues = metricValues(order);
        plot(ax, 100*maskRatio, metricValues, ...
            '-o', 'Color', colors(m,:), 'MarkerFaceColor', 'white', ...
            'LineWidth', 1.8, 'DisplayName', char(methods(m)));
    end
    boundaryLine = xline(ax, 60, '--', 'proposal fallback boundary', ...
        'Color', cfg.colors.red, 'LineWidth', 1.5);
    boundaryLine.HandleVisibility = 'off';
    xlabel(ax, 'mask area (% of image)'); ylabel(ax, strrep(metrics{p}, '_', ' '));
    title(ax, metricTitles{p}); xlim(ax, [0 80]); ylim(ax, [0 1.03]);
    grid(ax, 'on'); apply_axes_style(ax, cfg);
    if p == 1
        legend(ax, 'Location', 'southwest');
    end
end

ax4 = nexttile(tl, 4); hold(ax4, 'on');
axis(ax4, [0 1 0 1]); axis(ax4, 'off');
draw_flow_box(ax4, [0.04 0.72 0.26 0.14], ...
    ['Single-image prototype' newline 'coverage + stability pass'], ...
    [0.90 0.97 0.91], cfg.colors.green);
draw_flow_box(ax4, [0.39 0.72 0.26 0.14], ...
    ['Training conditional prototype' newline 'external reference'], ...
    [0.90 0.95 1.00], cfg.colors.blue);
draw_flow_box(ax4, [0.70 0.72 0.26 0.14], ...
    ['Conservative interval' newline 'no precise defect type'], ...
    [0.98 0.94 0.87], cfg.colors.orange);
draw_flow_box(ax4, [0.39 0.29 0.26 0.14], ...
    ['Human review' newline 'refuse automatic assessment'], ...
    [0.99 0.91 0.91], cfg.colors.red, 'FontWeight', 'bold');
draw_arrow(ax4, [0.305 0.79], [0.385 0.79], cfg.colors.dark, 1.4);
draw_arrow(ax4, [0.655 0.79], [0.695 0.79], cfg.colors.dark, 1.4);
draw_arrow(ax4, [0.83 0.705], [0.58 0.435], cfg.colors.red, 1.4);
text(ax4, 0.34, 0.84, 'mask > 60% / unstable views', ...
    'HorizontalAlignment', 'center', 'FontSize', 8, 'Color', cfg.colors.red);
text(ax4, 0.68, 0.84, 'domain shift', ...
    'HorizontalAlignment', 'center', 'FontSize', 8, 'Color', cfg.colors.red);
text(ax4, 0.73, 0.55, 'evidence remains insufficient', ...
    'Rotation', -35, 'HorizontalAlignment', 'center', ...
    'FontSize', 8, 'Color', cfg.colors.red);
title(ax4, '(d) Explicit fallback state machine');

add_figure_note(fig, 'simulation');
end
