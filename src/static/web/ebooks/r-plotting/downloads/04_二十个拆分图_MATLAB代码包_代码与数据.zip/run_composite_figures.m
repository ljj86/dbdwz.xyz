function summary = run_composite_figures()
%RUN_COMPOSITE_FIGURES Generate the five original four-panel figures.
cfg = setup_portable_paths();
cfg.export_dir = fullfile(cfg.package_dir, 'exports', 'composites');
jobs = {
    @fig04_conditional_gmm_pmp,      'fig04_conditional_gmm_pmp';
    @fig06_open_set_rejection,       'fig06_open_set_rejection';
    @figS01_parameter_sensitivity,   'figS01_parameter_sensitivity';
    @figS02_quality_heatmap_five_q,  'figS02_quality_heatmap_five_q';
    @figS03_failure_fallback,         'figS03_failure_fallback'
    };
summary = run_portable_jobs(cfg, jobs, 'composite');
end
